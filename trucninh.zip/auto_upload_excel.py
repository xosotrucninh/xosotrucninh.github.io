# -*- coding: utf-8 -*-
"""
TOOL TỰ ĐỘNG NẠP DỮ LIỆU BIỂU 31 & BIỂU 35 EXCEL LÊN FIREBASE
Phiên bản: XỔ SỐ KIẾN THIẾT TRỰC NINH (Firebase: xosotrucninh)
Hỗ trợ: Cả giao diện đồ họa (GUI) và dòng lệnh (CLI), file .xlsx và .xls
"""

import os
import sys
import re
import time
import json
import threading
import argparse
import urllib.request
import urllib.error
from datetime import datetime, timezone

# Đảm bảo in tiếng Việt và biểu tượng Unicode an toàn trên Windows cmd
try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

def safe_print(*args, **kwargs):
    try:
        print(*args, **kwargs)
    except Exception:
        try:
            clean_args = [str(a).encode('ascii', 'replace').decode('ascii') for a in args]
            print(*clean_args, **kwargs)
        except Exception:
            pass

# ==================== CẤU HÌNH FIREBASE TRỰC NINH ====================
FIREBASE_PROJECT_ID = "xosotrucninh"
FIREBASE_API_KEY = "AIzaSyCe0J33fpm_RfQbi372x4xeyldYx6WLuNc"
ADMIN_EMAIL = "apeo.d3@gmail.com"
ADMIN_PASSWORD = "Zeng6986"
APP_TITLE = "XỔ SỐ KIẾN THIẾT TRỰC NINH"
WINDOW_TITLE = "Nạp Excel Biểu 31 & 35 - Xổ Số Trực Ninh"

class FirebaseClient:
    def __init__(self, api_key, project_id, email, password):
        self.api_key = api_key
        self.project_id = project_id
        self.email = email
        self.password = password
        self.id_token = None
        self.token_expiry = 0
        self.base_url = f"https://firestore.googleapis.com/v1/projects/{self.project_id}/databases/(default)/documents"

    def authenticate(self):
        auth_url = f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={self.api_key}"
        payload = json.dumps({
            "email": self.email,
            "password": self.password,
            "returnSecureToken": True
        }).encode("utf-8")
        req = urllib.request.Request(auth_url, data=payload, headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                res = json.loads(resp.read().decode("utf-8"))
                self.id_token = res.get("idToken")
                expires_in = int(res.get("expiresIn", 3600))
                self.token_expiry = time.time() + expires_in - 120
                return True
        except Exception as e:
            raise RuntimeError(f"Lỗi đăng nhập Firebase Auth: {e}")

    def get_token(self):
        if not self.id_token or time.time() >= self.token_expiry:
            self.authenticate()
        return self.id_token

    def get_daily_record(self, doc_date):
        token = self.get_token()
        url = f"{self.base_url}/daily_records/{doc_date}"
        req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                fields = data.get("fields", {})
                records_val = fields.get("records", {}).get("arrayValue", {}).get("values", [])
                records = []
                for v in records_val:
                    m = v.get("mapValue", {}).get("fields", {})
                    records.append({
                        "ngay": m.get("ngay", {}).get("stringValue", doc_date),
                        "ma_dl": m.get("ma_dl", {}).get("stringValue", ""),
                        "loto_db": float(m.get("loto_db", {}).get("integerValue") or m.get("loto_db", {}).get("doubleValue") or 0),
                        "loto_cap": float(m.get("loto_cap", {}).get("integerValue") or m.get("loto_cap", {}).get("doubleValue") or 0),
                        "loto_2_27": float(m.get("loto_2_27", {}).get("integerValue") or m.get("loto_2_27", {}).get("doubleValue") or 0),
                        "loto_3_23": float(m.get("loto_3_23", {}).get("integerValue") or m.get("loto_3_23", {}).get("doubleValue") or 0),
                        "xskt": float(m.get("xskt", {}).get("integerValue") or m.get("xskt", {}).get("doubleValue") or 0),
                        "thuong": float(m.get("thuong", {}).get("integerValue") or m.get("thuong", {}).get("doubleValue") or 0),
                    })
                return records
        except urllib.error.HTTPError as he:
            if he.code == 404:
                return []
            raise
        except Exception:
            return []

    def save_daily_record(self, doc_date, records, is_monthly_summary=False):
        token = self.get_token()
        url = f"{self.base_url}/daily_records/{doc_date}"
        
        arr_values = []
        for r in records:
            arr_values.append({
                "mapValue": {
                    "fields": {
                        "ngay": {"stringValue": str(r.get("ngay", doc_date))},
                        "ma_dl": {"stringValue": str(r.get("ma_dl", ""))},
                        "loto_db": {"integerValue": str(int(r.get("loto_db", 0)))},
                        "loto_cap": {"integerValue": str(int(r.get("loto_cap", 0)))},
                        "loto_2_27": {"integerValue": str(int(r.get("loto_2_27", 0)))},
                        "loto_3_23": {"integerValue": str(int(r.get("loto_3_23", 0)))},
                        "xskt": {"integerValue": str(int(r.get("xskt", 0)))},
                        "thuong": {"integerValue": str(int(r.get("thuong", 0)))}
                    }
                }
            })

        doc_payload = {
            "fields": {
                "ngay": {"stringValue": doc_date},
                "count": {"integerValue": str(len(records))},
                "is_monthly_summary": {"booleanValue": bool(is_monthly_summary)},
                "records": {"arrayValue": {"values": arr_values}},
                "updated_at": {"timestampValue": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}
            }
        }

        req = urllib.request.Request(
            url,
            data=json.dumps(doc_payload).encode("utf-8"),
            headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
            method="PATCH"
        )
        with urllib.request.urlopen(req, timeout=20) as resp:
            return resp.status == 200

# ==================== PARSER EXCEL (BIỂU 31 & 35) ====================

def read_excel_rows(file_path):
    """Đọc file .xlsx hoặc .xls thành ma trận danh sách 2 chiều."""
    ext = os.path.splitext(file_path)[1].lower()
    rows = []
    if ext == ".xlsx":
        import openpyxl
        wb = openpyxl.load_workbook(file_path, data_only=True)
        ws = wb.active
        for r in ws.iter_rows(values_only=True):
            rows.append(list(r))
    elif ext == ".xls":
        import xlrd
        wb = xlrd.open_workbook(file_path)
        ws = wb.sheet_by_index(0)
        for r in range(ws.nrows):
            rows.append(ws.row_values(r))
    else:
        raise ValueError(f"Định dạng không hỗ trợ: {ext} (chỉ nhận .xlsx hoặc .xls)")
    return rows

def extract_date_info_from_rows(rows):
    """Trích xuất ngày tháng từ tiêu đề file biểu."""
    for r in range(min(20, len(rows))):
        row = rows[r]
        for c in range(len(row)):
            val = str(row[c] or "").strip()
            matches = re.findall(r"(\d{1,2})[/-](\d{1,2})(?:[/-](\d{2,4}))?", val)
            if matches and len(matches) >= 2:
                p1, p2 = matches[0], matches[1]
                d1, m1, y1 = int(p1[0]), int(p1[1]), int(p1[2]) if p1[2] else 2026
                d2, m2, y2 = int(p2[0]), int(p2[1]), int(p2[2]) if p2[2] else 2026
                if y1 < 100: y1 += 2000
                if d1 == 1 and d2 >= 28 and m1 == m2:
                    return f"{y1}-{m1:02d}-01", True
                return f"{y1}-{m1:02d}-{d1:02d}", False
            elif matches and len(matches) == 1:
                p = matches[0]
                d, m, y = int(p[0]), int(p[1]), int(p[2]) if p[2] else 2026
                if y < 100: y += 2000
                return f"{y}-{m:02d}-{d:02d}", False
    return "2026-08-01", False

def parse_b31_file(file_path):
    """Phân tích Biểu 31 (Lô tô)."""
    rows = read_excel_rows(file_path)
    date_str, is_monthly = extract_date_info_from_rows(rows)
    records = []
    for r in range(4, len(rows)):
        row = rows[r]
        if not row or len(row) < 4: continue
        ma_dl = str(row[1] or "").strip()
        if ma_dl.endswith(".0"): ma_dl = ma_dl[:-2]
        if not ma_dl or not any(ch.isdigit() for ch in ma_dl) or len(ma_dl) > 10: continue
        if any(k in ma_dl.upper() for k in ["TỔNG", "CỘNG", "TOTAL", "CÔNG"]): continue

        def get_f(idx):
            if idx < len(row) and row[idx] not in (None, ""):
                try: return float(row[idx])
                except Exception: return 0.0
            return 0.0

        records.append({
            "ngay": date_str,
            "ma_dl": ma_dl,
            "loto_db": get_f(3),
            "loto_cap": get_f(7),
            "loto_2_27": get_f(9),
            "loto_3_23": get_f(11),
            "xskt": 0.0,
            "thuong": get_f(15)
        })
    return date_str, is_monthly, records

def parse_b35_file(file_path):
    """Phân tích Biểu 35 (XSKT)."""
    rows = read_excel_rows(file_path)
    date_str, is_monthly = extract_date_info_from_rows(rows)
    code_col, xskt_col, header_row = -1, -1, -1

    for r in range(min(20, len(rows))):
        row = rows[r]
        if not row: continue
        for c, cell in enumerate(row):
            v_clean = re.sub(r"[\s._\xa0]+", "", str(cell or "").strip().upper())
            if v_clean in ["MADL", "MÃĐL", "MADAILY", "MADONVI", "MÃĐẠILÝ", "MÃĐƠNVỊ"]:
                code_col, header_row = c, r
            if v_clean == "XSKT" or "XSKT" in v_clean:
                xskt_col, header_row = c, r

    if code_col == -1: code_col = 1
    if xskt_col == -1: xskt_col = 8
    if header_row == -1: header_row = 4

    records = []
    for r in range(header_row + 1, len(rows)):
        row = rows[r]
        if not row or len(row) <= max(code_col, xskt_col): continue
        ma_dl = str(row[code_col] or "").strip()
        if ma_dl.endswith(".0"): ma_dl = ma_dl[:-2]
        if not ma_dl or not any(ch.isdigit() for ch in ma_dl) or len(ma_dl) > 10: continue
        if any(k in ma_dl.upper() for k in ["TỔNG", "CỘNG", "TOTAL", "CÔNG", "NGÀY", "BÁO", "STT"]): continue

        raw_val = str(row[xskt_col] or "").strip().replace(",", "")
        try: raw_num = float(raw_val)
        except Exception: raw_num = 0.0

        val_xskt = raw_num * 1000.0 if (0 < raw_num < 100000) else raw_num
        if val_xskt <= 0: continue

        records.append({
            "ngay": date_str,
            "ma_dl": ma_dl,
            "loto_db": 0.0, "loto_cap": 0.0, "loto_2_27": 0.0, "loto_3_23": 0.0, "thuong": 0.0,
            "xskt": val_xskt
        })
    return date_str, is_monthly, records

def classify_excel_file(file_path):
    """Xác định file Excel là Biểu 31 (Lô tô) hay Biểu 35 (XSKT)."""
    fname = os.path.basename(file_path).lower()
    full_path_lower = file_path.lower()

    if "31" in fname or "b31" in fname:
        return "31"
    if "35" in fname or "b35" in fname:
        return "35"
    if "\\31\\" in full_path_lower or "/31/" in full_path_lower or "b31" in full_path_lower:
        return "31"
    if "\\35\\" in full_path_lower or "/35/" in full_path_lower or "b35" in full_path_lower:
        return "35"

    try:
        rows = read_excel_rows(file_path)
        for r in range(min(15, len(rows))):
            row_str = " ".join(str(cell or "").upper() for cell in rows[r])
            if "XSKT" in row_str or "TRUYỀN THỐNG" in row_str:
                return "35"
            if any(k in row_str for k in ["LÔ TÔ", "LOTO", "CẶP", "2/27", "3/23", "ĐẶC BIỆT"]):
                return "31"
    except Exception:
        pass

    return None

def parse_time_window_seconds(text):
    """Chuyển đổi chuỗi thời gian như '1h', '30m', '2d' thành số giây."""
    if not text or not str(text).strip():
        return None
    s = str(text).strip().lower()
    if s in ["all", "tất cả", "tat ca", "0", "none", "*", "all time"]:
        return None
    m = re.match(r"^([0-9.]+)\s*([a-zà-ỹ]*)$", s)
    if not m:
        return None
    try:
        num = float(m.group(1))
    except ValueError:
        return None
    unit = m.group(2).strip()
    if unit in ["h", "gio", "giờ", "hour", "hours", ""]:
        return num * 3600
    elif unit in ["m", "p", "phut", "phút", "min", "mins"]:
        return num * 60
    elif unit in ["d", "ngay", "ngày", "day", "days"]:
        return num * 86400
    elif unit in ["s", "giay", "giây", "sec", "secs"]:
        return num
    return num * 3600

def scan_excel_folder(folder_path, time_window=None):
    """Quét đệ quy thư mục tìm Biểu 31 & 35, hỗ trợ lọc theo thời gian tạo/sửa."""
    b31_files = []
    b35_files = []
    total_excel = 0
    if not folder_path or not os.path.exists(folder_path):
        return b31_files, b35_files, 0

    sec_window = parse_time_window_seconds(time_window) if isinstance(time_window, str) else time_window
    now_ts = time.time()

    for root_dir, _, files in os.walk(folder_path):
        for f in files:
            if f.startswith("~$"):
                continue
            ext = os.path.splitext(f)[1].lower()
            if ext in [".xlsx", ".xls"]:
                full_path = os.path.join(root_dir, f)

                if sec_window is not None and sec_window > 0:
                    try:
                        f_time = max(os.path.getctime(full_path), os.path.getmtime(full_path))
                        if (now_ts - f_time) > sec_window:
                            continue
                    except Exception:
                        pass

                total_excel += 1
                c_type = classify_excel_file(full_path)
                if c_type == "31":
                    b31_files.append(full_path)
                elif c_type == "35":
                    b35_files.append(full_path)
    return b31_files, b35_files, total_excel

def process_and_upload(b31_files, b35_files, log_fn=safe_print, progress_fn=None):
    """Hợp nhất Biểu 31 & Biểu 35 và tải lên Firebase Firestore."""
    if progress_fn: progress_fn(5, f"Đang kết nối Firebase ({FIREBASE_PROJECT_ID})...")
    client = FirebaseClient(FIREBASE_API_KEY, FIREBASE_PROJECT_ID, ADMIN_EMAIL, ADMIN_PASSWORD)
    log_fn(f"🔐 Đang xác thực với Firebase '{FIREBASE_PROJECT_ID}' ({APP_TITLE})...")
    client.authenticate()
    log_fn(f"✅ Đăng nhập Firebase '{FIREBASE_PROJECT_ID}' thành công!")
    if progress_fn: progress_fn(15, "Đang đọc các file Excel...")

    data_by_date = {}
    total_b31_count = 0
    total_files = len(b31_files) + len(b35_files)
    processed_files = 0

    for f in b31_files:
        try:
            d_str, is_m, recs = parse_b31_file(f)
            total_b31_count += len(recs)
            log_fn(f"📄 Đã đọc Biểu 31 [{os.path.basename(f)}]: Ngày {d_str} ({len(recs)} bản ghi)")
            if d_str not in data_by_date:
                data_by_date[d_str] = {"b31": [], "b35": [], "is_monthly": is_m}
            data_by_date[d_str]["b31"].extend(recs)
            if is_m: data_by_date[d_str]["is_monthly"] = True
        except Exception as e:
            log_fn(f"❌ Lỗi đọc Biểu 31 [{os.path.basename(f)}]: {e}")
        processed_files += 1
        if progress_fn and total_files > 0:
            pct = 15 + int((processed_files / total_files) * 15)
            progress_fn(pct, f"Đang đọc file ({processed_files}/{total_files})...")

    total_b35_count = 0
    for f in b35_files:
        try:
            d_str, is_m, recs = parse_b35_file(f)
            total_b35_count += len(recs)
            log_fn(f"📄 Đã đọc Biểu 35 [{os.path.basename(f)}]: Ngày {d_str} ({len(recs)} bản ghi XSKT)")
            if d_str not in data_by_date:
                data_by_date[d_str] = {"b31": [], "b35": [], "is_monthly": is_m}
            data_by_date[d_str]["b35"].extend(recs)
            if is_m: data_by_date[d_str]["is_monthly"] = True
        except Exception as e:
            log_fn(f"❌ Lỗi đọc Biểu 35 [{os.path.basename(f)}]: {e}")
        processed_files += 1
        if progress_fn and total_files > 0:
            pct = 15 + int((processed_files / total_files) * 15)
            progress_fn(pct, f"Đang đọc file ({processed_files}/{total_files})...")

    target_dates = sorted(list(data_by_date.keys()))
    if not target_dates:
        log_fn("⚠️ Không có dữ liệu hợp lệ nào để tải lên.")
        if progress_fn: progress_fn(0, "Không có dữ liệu hợp lệ để tải lên.")
        return 0, 0

    log_fn(f"\n🔄 Bắt đầu gộp và tải lên Firebase cho {len(target_dates)} ngày: {', '.join(target_dates)}")

    total_uploaded = 0
    total_dates = len(target_dates)
    for idx, d in enumerate(target_dates):
        info = data_by_date[d]
        curr_step = idx + 1
        pct = 30 + int((curr_step / total_dates) * 70)
        if progress_fn:
            progress_fn(pct, f"Đang tải lên ngày {d} ({curr_step}/{total_dates} ngày - {pct}%)...")

        log_fn(f"⏳ Đang xử lý ngày {d}...")

        existing_recs = client.get_daily_record(d)
        merged_map = {}
        for r in existing_recs:
            merged_map[r["ma_dl"]] = dict(r)

        for r in info["b31"]:
            code = r["ma_dl"]
            if code in merged_map:
                cur = merged_map[code]
                cur["loto_db"] = r["loto_db"]
                cur["loto_cap"] = r["loto_cap"]
                cur["loto_2_27"] = r["loto_2_27"]
                cur["loto_3_23"] = r["loto_3_23"]
                cur["thuong"] = r["thuong"]
            else:
                merged_map[code] = {
                    "ngay": d, "ma_dl": code,
                    "loto_db": r["loto_db"], "loto_cap": r["loto_cap"],
                    "loto_2_27": r["loto_2_27"], "loto_3_23": r["loto_3_23"],
                    "xskt": 0.0, "thuong": r["thuong"]
                }

        for r in info["b35"]:
            code = r["ma_dl"]
            if code in merged_map:
                merged_map[code]["xskt"] = r["xskt"]
            else:
                merged_map[code] = {
                    "ngay": d, "ma_dl": code,
                    "loto_db": 0.0, "loto_cap": 0.0, "loto_2_27": 0.0, "loto_3_23": 0.0, "thuong": 0.0,
                    "xskt": r["xskt"]
                }

        final_recs = list(merged_map.values())
        final_recs.sort(key=lambda x: str(x["ma_dl"]))

        client.save_daily_record(d, final_recs, is_monthly_summary=info["is_monthly"])
        log_fn(f"  👉 Ngày {d}: Đã tải lên {len(final_recs)} bản ghi thành công!")
        total_uploaded += len(final_recs)

    if progress_fn: progress_fn(100, f"🎉 Đã nạp thành công {total_dates} ngày ({total_uploaded} bản ghi)!")
    log_fn(f"\n🎉 HOÀN TẤT! Đã đồng bộ thành công {len(target_dates)} ngày ({total_uploaded} bản ghi) lên Firebase {FIREBASE_PROJECT_ID}!\n")
    return len(target_dates), total_uploaded

# ==================== LƯU / ĐỌC CẤU HÌNH NGƯỜI DÙNG ====================
CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "upload_config.json")

def load_user_config():
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}

def save_user_config(data):
    try:
        cur = load_user_config()
        cur.update(data)
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cur, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

# ==================== GIAO DIỆN ĐỒ HỌA (TKINTER GUI) ====================

def launch_gui():
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox

    root = tk.Tk()
    root.title(WINDOW_TITLE)
    root.geometry("680x560")
    root.minsize(640, 500)
    root.configure(bg="#f8fafc")

    style = ttk.Style()
    try:
        style.theme_use('clam')
    except Exception:
        pass
    style.configure("Green.Horizontal.TProgressbar", foreground="#16a34a", background="#16a34a", thickness=10)

    tool_dir = os.path.dirname(os.path.abspath(__file__))
    user_cfg = load_user_config()
    saved_folder = user_cfg.get("last_folder", "").strip()
    init_folder = saved_folder if (saved_folder and os.path.exists(saved_folder)) else tool_dir

    current_folder_var = tk.StringVar(value=init_folder)
    time_window_var = tk.StringVar(value=user_cfg.get("time_window", "1h"))

    b31_list = []
    b35_list = []

    # 1. Header Frame gọn gàng
    head_frame = tk.Frame(root, bg="#15803d", pady=8, padx=12)
    head_frame.pack(fill=tk.X)

    title_row = tk.Frame(head_frame, bg="#15803d")
    title_row.pack(fill=tk.X)
    title_lbl = tk.Label(title_row, text=APP_TITLE, font=("Arial", 12, "bold"), fg="#ffffff", bg="#15803d")
    title_lbl.pack(side=tk.LEFT)
    tk.Label(title_row, text=f"● Firebase: {FIREBASE_PROJECT_ID}", font=("Arial", 9, "bold"), fg="#bbf7d0", bg="#15803d").pack(side=tk.RIGHT)

    # Main Container
    main_frame = tk.Frame(root, bg="#f8fafc", padx=10, pady=6)
    main_frame.pack(fill=tk.BOTH, expand=True)

    # 2. Khung Quét Thư Mục & Thời Gian (Gọn gàng trong 1 khung)
    cfg_frame = tk.LabelFrame(main_frame, text="Cấu Hình Quét File Excel (tự động quét cả thư mục con)", font=("Arial", 9, "bold"), fg="#0f172a", bg="#ffffff", padx=8, pady=6)
    cfg_frame.pack(fill=tk.X, pady=2)

    # Dòng 1: Chọn thư mục
    r1 = tk.Frame(cfg_frame, bg="#ffffff")
    r1.pack(fill=tk.X, pady=1)
    tk.Label(r1, text="📁 Thư mục:", font=("Arial", 9, "bold"), fg="#334155", bg="#ffffff", width=10, anchor="w").pack(side=tk.LEFT)
    entry_folder = tk.Entry(r1, textvariable=current_folder_var, font=("Consolas", 9), bg="#f8fafc", fg="#1e293b", relief=tk.SOLID, bd=1)
    entry_folder.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 6), ipady=3)
    entry_folder.bind("<Return>", lambda e: perform_scan())
    entry_folder.bind("<FocusOut>", lambda e: save_user_config({"last_folder": current_folder_var.get().strip()}))

    def on_choose_folder():
        chosen = filedialog.askdirectory(title="Chọn thư mục chứa file Excel Biểu 31 & 35", initialdir=current_folder_var.get())
        if chosen:
            current_folder_var.set(chosen)
            save_user_config({"last_folder": chosen})
            perform_scan()

    btn_choose = tk.Button(r1, text="📁 Chọn...", command=on_choose_folder, font=("Arial", 8, "bold"), bg="#e0f2fe", fg="#0369a1", padx=8, pady=2, cursor="hand2")
    btn_choose.pack(side=tk.LEFT, padx=(0, 4))

    def on_rescan():
        perform_scan()

    btn_rescan = tk.Button(r1, text="🔄 Quét Lại", command=on_rescan, font=("Arial", 8, "bold"), bg="#f1f5f9", fg="#334155", padx=8, pady=2, cursor="hand2")
    btn_rescan.pack(side=tk.LEFT)

    # Dòng 2: Thiết lập thời gian quét
    r2 = tk.Frame(cfg_frame, bg="#ffffff")
    r2.pack(fill=tk.X, pady=(4, 1))
    tk.Label(r2, text="⏱️ Excel được tạo trong khoảng thời gian:", font=("Arial", 9, "bold"), fg="#334155", bg="#ffffff").pack(side=tk.LEFT, padx=(0, 4))

    entry_time = tk.Entry(r2, textvariable=time_window_var, font=("Arial", 9), width=7, justify="center", relief=tk.SOLID, bd=1)
    entry_time.pack(side=tk.LEFT, padx=(0, 6), ipady=2)
    entry_time.bind("<Return>", lambda e: perform_scan())

    def set_time_quick(val):
        time_window_var.set(val)
        perform_scan()

    tk.Button(r2, text="Tất cả", command=lambda: set_time_quick(""), font=("Arial", 8), bg="#f1f5f9", padx=6, pady=1).pack(side=tk.LEFT, padx=1)
    tk.Button(r2, text="30 phút", command=lambda: set_time_quick("30m"), font=("Arial", 8), bg="#f1f5f9", padx=6, pady=1).pack(side=tk.LEFT, padx=1)
    tk.Button(r2, text="1 giờ", command=lambda: set_time_quick("1h"), font=("Arial", 8), bg="#f1f5f9", padx=6, pady=1).pack(side=tk.LEFT, padx=1)
    tk.Button(r2, text="4 giờ", command=lambda: set_time_quick("4h"), font=("Arial", 8), bg="#f1f5f9", padx=6, pady=1).pack(side=tk.LEFT, padx=1)
    tk.Button(r2, text="24 giờ", command=lambda: set_time_quick("24h"), font=("Arial", 8), bg="#f1f5f9", padx=6, pady=1).pack(side=tk.LEFT, padx=1)

    tk.Label(r2, text="(vd: 1h, 30m, 2d - để trống = tất cả)", font=("Arial", 8, "italic"), fg="#94a3b8", bg="#ffffff").pack(side=tk.LEFT, padx=6)

    # 3. Khung Thống Kê File Nhận Diện Được (2 Cột Gọn Nhẹ)
    summary_frame = tk.LabelFrame(main_frame, text="Kết quả tự động nhận diện file", font=("Arial", 9, "bold"), fg="#0f172a", bg="#ffffff", padx=8, pady=6)
    summary_frame.pack(fill=tk.X, pady=3)

    cards_row = tk.Frame(summary_frame, bg="#ffffff")
    cards_row.pack(fill=tk.X)

    # Card Biểu 31
    c31 = tk.Frame(cards_row, bg="#f0f9ff", bd=1, relief=tk.SOLID, padx=8, pady=4)
    c31.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 4))
    r31 = tk.Frame(c31, bg="#f0f9ff")
    r31.pack(fill=tk.X)
    tk.Label(r31, text="📋 Biểu 31 (Lô tô):", font=("Arial", 9, "bold"), fg="#0369a1", bg="#f0f9ff").pack(side=tk.LEFT)
    lbl_count_31 = tk.Label(r31, text="0 file", font=("Arial", 9, "bold"), fg="#0284c7", bg="#f0f9ff")
    lbl_count_31.pack(side=tk.RIGHT)
    lbl_files_31 = tk.Label(c31, text="Chưa có file nào", font=("Arial", 8), fg="#64748b", bg="#f0f9ff", wraplength=300, justify="left")
    lbl_files_31.pack(anchor="w")

    # Card Biểu 35
    c35 = tk.Frame(cards_row, bg="#f0fdf4", bd=1, relief=tk.SOLID, padx=8, pady=4)
    c35.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(4, 0))
    r35 = tk.Frame(c35, bg="#f0fdf4")
    r35.pack(fill=tk.X)
    tk.Label(r35, text="📋 Biểu 35 (XSKT):", font=("Arial", 9, "bold"), fg="#15803d", bg="#f0fdf4").pack(side=tk.LEFT)
    lbl_count_35 = tk.Label(r35, text="0 file", font=("Arial", 9, "bold"), fg="#16a34a", bg="#f0fdf4")
    lbl_count_35.pack(side=tk.RIGHT)
    lbl_files_35 = tk.Label(c35, text="Chưa có file nào", font=("Arial", 8), fg="#64748b", bg="#f0fdf4", wraplength=300, justify="left")
    lbl_files_35.pack(anchor="w")

    # Dải trạng thái tóm tắt
    lbl_status_bar = tk.Label(summary_frame, text="Đang chuẩn bị quét...", font=("Arial", 8, "bold"), bg="#f8fafc", fg="#475569", pady=3)
    lbl_status_bar.pack(fill=tk.X, pady=(4, 0))

    # 4. Thanh Tiến Trình (Progress Bar)
    pbar_frame = tk.Frame(main_frame, bg="#f8fafc", pady=2)
    pbar_frame.pack(fill=tk.X)

    pbar_header = tk.Frame(pbar_frame, bg="#f8fafc")
    pbar_header.pack(fill=tk.X, pady=(0, 2))
    lbl_progress_title = tk.Label(pbar_header, text="Tiến trình:", font=("Arial", 8, "bold"), fg="#475569", bg="#f8fafc")
    lbl_progress_title.pack(side=tk.LEFT)
    lbl_progress = tk.Label(pbar_header, text="Sẵn sàng (0%)", font=("Arial", 8), fg="#64748b", bg="#f8fafc")
    lbl_progress.pack(side=tk.RIGHT)

    progress_bar = ttk.Progressbar(pbar_frame, orient="horizontal", style="Green.Horizontal.TProgressbar", mode="determinate")
    progress_bar.pack(fill=tk.X)

    # 5. Nút bấm Upload chính
    btn_upload = tk.Button(main_frame, text=f"🚀 BẮT ĐẦU NẠP LÊN FIREBASE ({FIREBASE_PROJECT_ID})", font=("Arial", 11, "bold"), bg="#15803d", fg="#ffffff", padx=16, pady=6, relief=tk.RAISED, cursor="hand2")
    btn_upload.pack(fill=tk.X, pady=4)

    # 6. Khung Log hiển thị tiến trình
    log_frame = tk.LabelFrame(main_frame, text="Nhật Ký Quá Trình Nạp", font=("Arial", 8, "bold"), fg="#475569", bg="#ffffff", padx=6, pady=4)
    log_frame.pack(fill=tk.BOTH, expand=True, pady=2)

    txt_log = tk.Text(log_frame, wrap=tk.WORD, font=("Consolas", 8), bg="#0f172a", fg="#f8fafc", height=8)
    txt_log.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    scroll = tk.Scrollbar(log_frame, command=txt_log.yview)
    scroll.pack(side=tk.RIGHT, fill=tk.Y)
    txt_log.config(yscrollcommand=scroll.set)

    def log(msg):
        def _append():
            txt_log.insert(tk.END, msg + "\n")
            txt_log.see(tk.END)
        root.after(0, _append)

    def update_progress(pct, status_text):
        def _update():
            progress_bar["value"] = pct
            lbl_progress.config(text=f"{status_text}")
        root.after(0, _update)

    def perform_scan():
        nonlocal b31_list, b35_list
        folder_path = current_folder_var.get().strip()
        t_filter = time_window_var.get().strip()

        save_user_config({
            "last_folder": folder_path,
            "time_window": t_filter
        })

        time_desc = f" (chỉ lấy file tạo trong {t_filter})" if t_filter else " (tất cả thời gian)"
        log(f"\n🔍 Đang quét: [{folder_path}]{time_desc}...")

        b31, b35, total_excel = scan_excel_folder(folder_path, time_window=t_filter)
        b31_list = b31
        b35_list = b35

        lbl_count_31.config(text=f"{len(b31_list)} file")
        if b31_list:
            fnames = [os.path.basename(f) for f in b31_list[:2]]
            preview = ", ".join(fnames) + ("..." if len(b31_list) > 2 else "")
            lbl_files_31.config(text=preview, fg="#0369a1")
        else:
            lbl_files_31.config(text="Không tìm thấy file nào", fg="#94a3b8")

        lbl_count_35.config(text=f"{len(b35_list)} file")
        if b35_list:
            fnames = [os.path.basename(f) for f in b35_list[:2]]
            preview = ", ".join(fnames) + ("..." if len(b35_list) > 2 else "")
            lbl_files_35.config(text=preview, fg="#15803d")
        else:
            lbl_files_35.config(text="Không tìm thấy file nào", fg="#94a3b8")

        if b31_list or b35_list:
            lbl_status_bar.config(
                text=f"✅ Đã tìm thấy {len(b31_list)} file Biểu 31 và {len(b35_list)} file Biểu 35 sẵn sàng nạp!",
                bg="#dcfce7", fg="#15803d"
            )
            btn_upload.config(state=tk.NORMAL, bg="#15803d", text=f"🚀 BẮT ĐẦU NẠP LÊN FIREBASE ({FIREBASE_PROJECT_ID})")
            log(f"⚡ Kết quả: {len(b31_list)} file Biểu 31, {len(b35_list)} file Biểu 35 (tổng {total_excel} file Excel).")
            log(f"👉 Nhấn nút 'BẮT ĐẦU NẠP LÊN FIREBASE ({FIREBASE_PROJECT_ID})' để nạp toàn bộ.")
        else:
            lbl_status_bar.config(
                text=f"⚠️ Chưa tìm thấy file Excel Biểu 31 hay 35 nào{time_desc}.",
                bg="#fef3c7", fg="#b45309"
            )
            btn_upload.config(state=tk.NORMAL, bg="#64748b", text=f"🚀 BẮT ĐẦU NẠP LÊN FIREBASE ({FIREBASE_PROJECT_ID})")
            log(f"⚠️ Không tìm thấy file Biểu 31 hoặc 35 nào trong '{folder_path}'{time_desc}.")
            if t_filter:
                log("💡 Gợi ý: Có thể file được tạo lâu hơn. Hãy thử xóa ô thời gian hoặc chọn [Tất cả] để quét.")

    def do_upload():
        if not b31_list and not b35_list:
            messagebox.showwarning(
                "Chưa có file Excel",
                "Chưa tìm thấy file Biểu 31 hoặc Biểu 35 nào phù hợp!\n\nVui lòng bấm '📁 Chọn...' để chọn thư mục hoặc xóa bộ lọc thời gian."
            )
            return

        btn_upload.config(state=tk.DISABLED, text=f"⏳ ĐANG XỬ LÝ & NẠP DỮ LIỆU LÊN {FIREBASE_PROJECT_ID}...")
        btn_choose.config(state=tk.DISABLED)
        btn_rescan.config(state=tk.DISABLED)
        countdown_timer_id = None
        countdown_remaining = 0

        def cancel_countdown():
            nonlocal countdown_timer_id
            if countdown_timer_id:
                root.after_cancel(countdown_timer_id)
                countdown_timer_id = None
                lbl_status_bar.config(text="🛑 Đã hủy đếm ngược. Tool vẫn đang mở.", bg="#f1f5f9", fg="#334155")
                btn_upload.config(state=tk.NORMAL, text=f"🚀 BẮT ĐẦU NẠP LÊN FIREBASE ({FIREBASE_PROJECT_ID})", bg="#15803d", command=do_upload)
                log("🛑 Đã hủy tự động tắt tool. Bạn có thể tiếp tục sử dụng.")

        def on_upload_success(days, recs):
            nonlocal countdown_timer_id, countdown_remaining
            log(f"\n🎉 HOÀN TẤT NẠP DỮ LIỆU! Đã nạp thành công {days} ngày ({recs} bản ghi) lên Firebase {FIREBASE_PROJECT_ID}.")
            log("⏰ Chương trình sẽ tự động đếm ngược 15 giây và tắt tool...")

            countdown_remaining = 15

            def tick():
                nonlocal countdown_timer_id, countdown_remaining
                if countdown_remaining > 0:
                    lbl_status_bar.config(
                        text=f"🎉 NẠP THÀNH CÔNG {days} NGÀY ({recs} BẢN GHI) LÊN {FIREBASE_PROJECT_ID}! Tự động tắt sau {countdown_remaining}s...",
                        bg="#dcfce7", fg="#15803d"
                    )
                    btn_upload.config(
                        state=tk.NORMAL,
                        text=f"⏹️ BẤM VÀO ĐÂY ĐỂ HỦY TẮT TOOL (Tự đóng sau {countdown_remaining}s...)",
                        bg="#dc2626", fg="#ffffff",
                        command=cancel_countdown
                    )
                    countdown_remaining -= 1
                    countdown_timer_id = root.after(1000, tick)
                else:
                    log("👋 Đã hết 15 giây. Tự động đóng tool...")
                    root.destroy()

            tick()

        def worker():
            success = False
            days, recs = 0, 0
            try:
                days, recs = process_and_upload(b31_list, b35_list, log_fn=log, progress_fn=update_progress)
                success = True
            except Exception as e:
                log(f"\n❌ LỖI TRONG QUÁ TRÌNH NẠP: {e}")
                update_progress(0, f"❌ Lỗi: {e}")
                root.after(0, lambda: messagebox.showerror("Lỗi Nạp Dữ Liệu", f"Có lỗi xảy ra:\n{e}"))
            finally:
                root.after(0, lambda: btn_choose.config(state=tk.NORMAL))
                root.after(0, lambda: btn_rescan.config(state=tk.NORMAL))
                if success:
                    root.after(0, lambda: on_upload_success(days, recs))
                else:
                    root.after(0, lambda: btn_upload.config(state=tk.NORMAL, text=f"🚀 BẮT ĐẦU NẠP LÊN FIREBASE ({FIREBASE_PROJECT_ID})", bg="#15803d", command=do_upload))

        threading.Thread(target=worker, daemon=True).start()

    btn_upload.config(command=do_upload)

    # Tự động quét khi bật chương trình
    root.after(100, perform_scan)

    root.mainloop()

# ==================== XỬ LÝ DÒNG LỆNH (CLI) ====================

def main():
    parser = argparse.ArgumentParser(description=f"Tool tự động nạp Biểu 31 & Biểu 35 Excel lên Firebase {FIREBASE_PROJECT_ID}")
    parser.add_argument("--b31", nargs="*", help="Đường dẫn file Biểu 31 (.xlsx, .xls)")
    parser.add_argument("--b35", nargs="*", help="Đường dẫn file Biểu 35 (.xlsx, .xls)")
    parser.add_argument("--folder", help="Đường dẫn thư mục chứa các file biểu (quét cả thư mục con)")
    parser.add_argument("--time", help="Khoảng thời gian tạo file (vd: 1h, 30m, 2d)")
    parser.add_argument("--watch", help="Đường dẫn thư mục giám sát tự động (thả file là tự nạp)")

    args = parser.parse_args()

    if len(sys.argv) == 1:
        launch_gui()
        return

    b31_files = args.b31 or []
    b35_files = args.b35 or []

    if args.folder:
        f31, f35, _ = scan_excel_folder(args.folder, time_window=args.time)
        b31_files.extend(f31)
        b35_files.extend(f35)

    if args.watch:
        print(f"👀 Đang theo dõi thư mục: {args.watch} (Dự án: {FIREBASE_PROJECT_ID}) (Bấm Ctrl+C để dừng)...")
        processed = set()
        while True:
            try:
                new_31, new_35 = [], []
                f31, f35, _ = scan_excel_folder(args.watch, time_window=args.time)
                for path in f31:
                    if path not in processed:
                        new_31.append(path)
                for path in f35:
                    if path not in processed:
                        new_35.append(path)

                if new_31 or new_35:
                    print(f"\n⚡ Phát hiện {len(new_31)} file 31, {len(new_35)} file 35 mới. Bắt đầu nạp lên {FIREBASE_PROJECT_ID}...")
                    process_and_upload(new_31, new_35, log_fn=print)
                    processed.update(new_31)
                    processed.update(new_35)
                time.sleep(5)
            except KeyboardInterrupt:
                break
            except Exception as e:
                print("Lỗi theo dõi thư mục:", e)
                time.sleep(5)
        return

    if not b31_files and not b35_files:
        print("Vui lòng cung cấp ít nhất một file --b31, --b35 hoặc --folder")
        sys.exit(1)

    process_and_upload(b31_files, b35_files, log_fn=safe_print)

if __name__ == "__main__":
    main()
