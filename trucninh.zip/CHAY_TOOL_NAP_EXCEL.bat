@echo off
chcp 65001 >nul
title Nạp Excel Biểu 31 & 35 - Xổ Số Trực Ninh
cd /d "C:\inetpub\wwwroot\trucninh"
python auto_upload_excel.py
if errorlevel 1 (
    echo.
    echo Co loi xay ra hoac Python chua duoc them vao PATH.
    pause
)
