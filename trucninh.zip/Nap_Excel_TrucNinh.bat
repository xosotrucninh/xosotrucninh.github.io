@echo off
title Nap Excel Truc Ninh len Firebase
call "C:\inetpub\wwwroot\trucninh\CHAY_TOOL_NAP_EXCEL.bat"
